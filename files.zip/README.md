# 🚀 Dreams Come True Backend — Guía Render (GRATIS)

Instrucciones paso a paso para subir tu backend a **Render.com** sin gastar dinero.

---

## 📋 REQUISITOS (antes de empezar)

Tienes que tener listos:
1. **Cuenta de GitHub** (gratis en github.com)
2. **Cuenta en Render** (gratis en render.com)
3. **API Key de Gemini** (ya la tienes en aistudio.google.com)
4. **Stripe Keys** (ya las tienes en dashboard.stripe.com)

---

## ⚙️ PASO 1 — Preparar el código en GitHub

### 1.1 Crear repositorio en GitHub

1. Ve a **github.com** e inicia sesión
2. Click en **"New repository"** (esquina arriba a la derecha)
3. Completa así:
   - **Repository name:** `dreams-come-true-backend`
   - **Description:** Backend para Dreams Come True
   - **Public** (selecciona esto)
   - Click **"Create repository"**

### 1.2 Subir los archivos

1. Copia los 3 archivos que te di:
   - `server.js`
   - `package.json`
   - `.env.example`

2. En tu repositorio de GitHub, click en **"Add file"** → **"Upload files"**

3. Arrastra o selecciona los 3 archivos

4. Click **"Commit changes"**

---

## 🎯 PASO 2 — Desplegar a Render (5 minutos)

### 2.1 Conectar Render con GitHub

1. Ve a **render.com**
2. Click **"New +"** → **"Web Service"**
3. Click **"Connect a repository"**
4. Busca `dreams-come-true-backend`
5. Click **"Connect"**

### 2.2 Configurar el servicio

Completa los campos así:

| Campo | Valor |
|-------|-------|
| **Name** | dreams-come-true-backend |
| **Region** | Ohio (u otro cercano) |
| **Branch** | main |
| **Runtime** | Node |
| **Build Command** | `npm install` |
| **Start Command** | `node server.js` |

### 2.3 Agregar variables de entorno

En la misma pantalla, scroll down hasta **"Environment Variables"**

Agrega estas:

```
GEMINI_API_KEY = tu_clave_de_gemini_aqui
STRIPE_SECRET_KEY = sk_live_tu_clave_stripe_aqui
STRIPE_WEBHOOK_SECRET = whsec_tu_secret_aqui
PORT = 3000
FRONTEND_URL = http://localhost:3000
```

**¿Cómo obtener las claves?**

**Gemini API Key:**
1. Ve a **aistudio.google.com**
2. Busca "API Key" arriba a la derecha
3. Copia la clave

**Stripe Keys:**
1. Ve a **dashboard.stripe.com**
2. Click **"Developers"** (abajo a la izquierda)
3. Busca **"API Keys"**
4. Copia **"Secret key"** (comienza con `sk_live_`)

### 2.4 Deploy

Click **"Deploy"** y espera 2-3 minutos.

Cuando termine, verás algo así:

```
✓ Your service is live at:
  https://dreams-come-true-backend.onrender.com
```

**¡Listo! Tu backend está en internet.**

---

## ✅ VERIFICAR QUE FUNCIONA

Abre en tu navegador:
```
https://dreams-come-true-backend.onrender.com/health
```

Deberías ver:
```json
{
  "status": "Servidor Dreams Come True ✓",
  "time": "2026-06-01T21:00:00.000Z"
}
```

---

## 🔗 CONECTAR CON LA APP

Una vez que tengas la URL (ejemplo: `https://dreams-come-true-backend.onrender.com`), 

**Me das esta URL y yo:**
1. Actualizo la app React para que hable con el backend
2. Conecto Stripe real para pagos
3. Conecto Gemini para generación de sueños
4. Todo está listo para publicar

---

## 💡 NOTAS IMPORTANTES

- **Plan gratis de Render:** Suficiente para empezar. Si crece, pasa a plan pagado ($7/mes)
- **Las variables de entorno son secretas** — nunca las compartas
- **Si actualizas el código en GitHub** → Render redeploya automáticamente
- **First request tarda un poco** → Es normal en el plan gratis

---

## 🚨 SI ALGO FALLA

Si ves error al desplegar, mira los **"Logs"** en Render (click en tu servicio → "Logs")

Errores comunes:
- `PORT not found` → Asegúrate de agregar `PORT=3000` en variables
- `GEMINI_API_KEY undefined` → Copia bien la clave sin espacios
- `Module not found` → Ejecuta `npm install` localmente primero

---

## 📞 PRÓXIMOS PASOS

1. ✅ Subir backend a Render (tú haces esto)
2. ✅ Mandarme la URL del backend
3. ✅ Yo conecto todo en la app
4. ✅ Generar videos de muestra
5. ✅ Publicar en App Store y Google Play

---

**¿Necesitas ayuda? Pregunta en cualquier momento.**
