import express from 'express';
import cors from 'cors';
import { GoogleGenerativeAI } from '@google/generative-ai';
import Stripe from 'stripe';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// APIs
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// ============ DATOS EN MEMORIA ============
// Nota: En producción usa PostgreSQL o MongoDB
const dreams = [];
const users = {};

// ============ RUTAS SALUD ============
app.get('/health', (req, res) => {
  res.json({ status: 'Servidor Dreams Come True ✓', time: new Date().toISOString() });
});

// ============ RUTAS GENERACIÓN ============

// Generar sueño con IA
app.post('/api/dreams/generate', async (req, res) => {
  try {
    const { text, style, duration } = req.body;

    if (!text || !style) {
      return res.status(400).json({ error: 'Faltan parámetros: text y style' });
    }

    // Prompts por estilo
    const stylePrompts = {
      real: "Fotorrealista, cinematográfico, 4K",
      anime: "Anime épico, Ghibli style, colores vibrantes, 4K",
      cyber: "Cyberpunk, neón, futurista, luces eléctricas, 4K",
      fantasy: "Fantasy épico, mágico, colores fantásticos, 4K",
      ghibli: "Studio Ghibli, acuarela digital, naturaleza mágica, 4K",
      acuarela: "Acuarela artística, colores suaves, hermoso, 4K",
      pixel: "Pixel art retro, vibrante, 8-bit style, 4K",
      terror: "Horror cinematográfico, atmósfera oscura, tensión, 4K",
    };

    const fullPrompt = `${text}. Estilo: ${stylePrompts[style] || 'cinematográfico'}. Sin texto. Duración: ${duration}s`;

    // Simular generación (en producción llamaría a Veo 3)
    // Para ahora, retornamos una respuesta mock
    const dreamId = Date.now();
    
    const dream = {
      id: dreamId,
      text,
      style,
      duration,
      prompt: fullPrompt,
      videoUrl: `https://via.placeholder.com/720x1280?text=Dream+${dreamId}`,
      createdAt: new Date(),
      status: 'completed'
    };

    dreams.push(dream);

    res.json({
      success: true,
      dream,
      message: 'Video generado exitosamente',
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Obtener sueños del usuario
app.get('/api/dreams/user/:userId', (req, res) => {
  const userDreams = dreams.filter(d => d.userId === req.params.userId);
  res.json({ dreams: userDreams, total: userDreams.length });
});

// Obtener todos los sueños públicos (comunidad)
app.get('/api/dreams/community', (req, res) => {
  const publicDreams = dreams.filter(d => d.isPublic);
  res.json({ dreams: publicDreams, total: publicDreams.length });
});

// ============ RUTAS USUARIOS ============

// Crear usuario
app.post('/api/users', (req, res) => {
  try {
    const { name, email } = req.body;
    const userId = Date.now().toString();

    users[userId] = {
      id: userId,
      name,
      email,
      plan: 'free',
      credits: 3,
      createdAt: new Date(),
    };

    res.json({ success: true, user: users[userId] });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obtener usuario
app.get('/api/users/:userId', (req, res) => {
  const user = users[req.params.userId];
  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }
  res.json(user);
});

// ============ RUTAS PAGOS STRIPE ============

// Crear sesión de checkout para video individual
app.post('/api/payments/buy-video', async (req, res) => {
  try {
    const { duration, userId } = req.body;

    const prices = {
      10: 199,
      30: 699,
      45: 999,
      60: 1499,
    };

    const amount = prices[duration];
    if (!amount) {
      return res.status(400).json({ error: 'Duración inválida' });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: `Video de sueño ${duration}s`,
              description: 'Genera un video de tu sueño con IA',
            },
            unit_amount: amount,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/cancel`,
      metadata: { userId, duration },
    });

    res.json({ success: true, sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Crear sesión de checkout para suscripción
app.post('/api/payments/subscribe', async (req, res) => {
  try {
    const { plan, userId } = req.body;

    const plans = {
      soñador: 'price_soñador_monthly',
      epico: 'price_epico_monthly',
    };

    const priceId = plans[plan];
    if (!priceId) {
      return res.status(400).json({ error: 'Plan inválido' });
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/cancel`,
      metadata: { userId, plan },
    });

    res.json({ success: true, sessionId: session.id, url: session.url });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Webhook de Stripe (verificar pagos)
app.post('/api/payments/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (error) {
    return res.status(400).send(`Webhook Error: ${error.message}`);
  }

  // Manejar eventos
  if (event.type === 'payment_intent.succeeded') {
    console.log('Pago completado:', event.data.object);
  }

  if (event.type === 'customer.subscription.created') {
    console.log('Suscripción creada:', event.data.object);
  }

  res.json({ received: true });
});

// ============ INICIAR SERVIDOR ============
app.listen(PORT, () => {
  console.log(`✨ Dreams Come True Backend corriendo en puerto ${PORT}`);
  console.log(`🌐 http://localhost:${PORT}`);
  console.log(`🏥 Health check: http://localhost:${PORT}/health`);
});
